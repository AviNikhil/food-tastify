package com.infinite.repository;

import java.util.List;
import com.infinite.model.OrderHistory;

public interface IAdmin_OHDao {
	public List<OrderHistory> getOrderHistory();
	
}
