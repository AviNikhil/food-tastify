package com.infinite.service;

import java.util.List;

import com.infinite.model.OrderHistory;


public interface IAdmin_OHService {
	public List<OrderHistory> getOrderHistory();
}
